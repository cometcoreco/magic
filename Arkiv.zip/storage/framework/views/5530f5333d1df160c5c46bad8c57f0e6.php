<!-- Start image generator -->
<?php if($openai->type == 'image'): ?>
    <div class="row row-deck row-cards">
        <div class="col-12">
            <div class="card bg-[#F3E2FD] !shadow-sm group-[.theme-dark]/body:bg-[#14171C] group-[.theme-dark]/body:shadow-black">
                <div class="card-body md:p-10">
                    <div class="row">
                        <label for="description" class="h2 mb-3"><?php echo e(__('Explain your idea')); ?>. | <a onclick="return fillAnExample();" class="text-success" href="">Fill an Example</a> </label>
                        <form id="openai_generator_form" onsubmit="return sendOpenaiGeneratorForm();">
                            <div class="relative mb-3">
                                <?php
                                    $placeholders = [
                                        'Cityscape at sunset in retro vector illustration ',
                                        'Painting of a flower vase on a kitchen table with a window in the backdrop.',
                                        'Memphis style painting of a flower vase on a kitchen table with a window in the backdrop.',
                                        'Illustration of a cat sitting on a couch in a living room with a coffee mug in its hand.',
                                        'Delicious pizza with all the toppings.'];
                                ?>
                                <?php $__currentLoopData = json_decode($openai->questions); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($question->type == 'textarea'): ?>
                                        <input class="form-control bg-[#fff] rounded-full h-[53px] text-[#000] !shadow-sm placeholder:text-black image-input-for-fillanexample group-[.theme-dark]/body:placeholder:text-white" type="text" id="<?php echo e($question->name); ?>" name="<?php echo e($question->name); ?>" placeholder="<?php echo e($placeholders[array_rand($placeholders)]); ?>">
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <button id="openai_generator_button" class="btn btn-primary h-[36px] absolute top-1/2 end-[1rem] -translate-y-1/2 hover:-translate-y-1/2 hover:scale-110 max-lg:relative max-lg:top-auto max-lg:right-auto max-lg:translate-y-0 max-lg:w-full max-lg:mt-2" type="submit">
                                    Generate
                                    <svg class="!ms-2 rtl:-scale-x-100 translate-x-0 translate-y-0" width="14" height="13" viewBox="0 0 14 13" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M7.25 13L6.09219 11.8625L10.6422 7.3125H0.75V5.6875H10.6422L6.09219 1.1375L7.25 0L13.75 6.5L7.25 13Z"/>
                                    </svg>
                                </button>
                            </div>
                            <div class="flex flex-wrap justify-between">
                                <a href="#advanced-settings" class="flex items-center text-[11px] font-semibold text-heading hover:no-underline group collapsed" data-bs-toggle="collapse" data-bs-auto-close="false">
                                    <?php echo e(__('Advanced Settings')); ?>

                                    <span class="inline-flex items-center justify-center w-[36px] h-[36px] p-0 !ms-2 bg-white !shadow-sm rounded-full group-[.theme-dark]/body:!bg-[--tblr-bg-surface]">
										<svg class="hidden group-[&.collapsed]:block" width="12" height="12" viewBox="0 0 12 12" fill="var(--lqd-heading-color)" xmlns="http://www.w3.org/2000/svg">
											<path d="M6.76708 5.464H11.1451V7.026H6.76708V11.558H5.18308V7.026H0.805078V5.464H5.18308V0.909999H6.76708V5.464Z"/>
										</svg>
										<svg class="block group-[&.collapsed]:hidden" width="6" height="2" viewBox="0 0 6 2" fill="var(--lqd-heading-color)" xmlns="http://www.w3.org/2000/svg">
											<path d="M0.335078 1.962V0.246H5.65908V1.962H0.335078Z"/>
										</svg>
									</span>
                                </a>

                                <div class="max-sm:-order-1 max-sm:mb-4 max-sm:w-full">
                                    <div class="flex justify-between flex-wrap mb-2">
                                        <div class="flex items-center mr-3">
                                            <span class="legend !me-2 rounded-full bg-primary" style="--tblr-legend-size:0.5rem;"></span>
                                            <span><?php echo e(__('Words')); ?></span>
                                            <span class="ms-2 text-heading font-medium"><?php echo e(number_format((int)Auth::user()->remaining_words)); ?></span>
                                        </div>
                                        <div class="flex items-center">
                                            <span class="legend !me-2 rounded-full bg-[#9E9EFF]" style="--tblr-legend-size:0.5rem;"></span>
                                            <span><?php echo e(__('Images')); ?></span>
                                            <span class="ms-2 text-heading font-medium"><?php echo e(number_format((int)Auth::user()->remaining_images)); ?></span>
                                        </div>
                                    </div>
                                    <div class="progress progress-separated h-1">
                                        <?php if((int)Auth::user()->remaining_words+(int)Auth::user()->remaining_images != 0): ?>
                                            <div class="progress-bar grow-0 shrink-0 basis-auto bg-primary" role="progressbar" style="width: <?php echo e((int)Auth::user()->remaining_words/((int)Auth::user()->remaining_words+(int)Auth::user()->remaining_images)*100); ?>%" aria-label="<?php echo e(__('Text')); ?>"></div>
                                        <?php endif; ?>
                                        <?php if((int)Auth::user()->remaining_words+(int)Auth::user()->remaining_images != 0): ?>
                                            <div class="progress-bar grow-0 shrink-0 basis-auto bg-[#9E9EFF]" role="progressbar" style="width: <?php echo e((int)Auth::user()->remaining_images/((int)Auth::user()->remaining_words+(int)Auth::user()->remaining_images)*100); ?>%" aria-label="<?php echo e(__('Images')); ?>"></div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                            <div id="advanced-settings" class="collapse">
                                <div class="flex flex-wrap justify-between gap-3 mt-8">
                                    <?php $__currentLoopData = json_decode($openai->questions); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($question->type == 'select'): ?>
                                            <div class="grow">
                                                <label for="<?php echo e($question->name); ?>" class="form-label text-heading"><?php echo e(__('Image resolution')); ?></label>
                                                <select class="form-control form-select bg-white placeholder:text-black" name="<?php echo e($question->name); ?>" id="<?php echo e($question->name); ?>">
                                                    <?php echo $question->select; ?>

                                                </select>
                                            </div>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <div class="grow">
                                            <label for="image_style" class="form-label text-heading"><?php echo e(__('Art Style')); ?></label>
                                            <select name="image_style" id="image_style" class="form-control form-select bg-white placeholder:text-black">
                                                <option value="" selected="selected"><?php echo e(__('None')); ?></option>
                                                <option value="3d_render"><?php echo e(__('3D Render')); ?></option>
                                                <option value="anime"><?php echo e(__('Anime')); ?></option>
                                                <option value="ballpoint_pen"><?php echo e(__('Ballpoint Pen Drawing')); ?></option>
                                                <option value="bauhaus"><?php echo e(__('Bauhaus')); ?></option>
                                                <option value="cartoon"><?php echo e(__('Cartoon')); ?></option>
                                                <option value="clay"><?php echo e(__('Clay')); ?></option>
                                                <option value="contemporary"><?php echo e(__('Contemporary')); ?></option>
                                                <option value="cubism"><?php echo e(__('Cubism')); ?></option>
                                                <option value="cyberpunk"><?php echo e(__('Cyberpunk')); ?></option>
                                                <option value="glitchcore"><?php echo e(__('Glitchcore')); ?></option>
                                                <option value="impressionism"><?php echo e(__('Impressionism')); ?></option>
                                                <option value="isometric"><?php echo e(__('Isometric')); ?></option>
                                                <option value="line"><?php echo e(__('Line Art')); ?></option>
                                                <option value="low_poly"><?php echo e(__('Low Poly')); ?></option>
                                                <option value="minimalism"><?php echo e(__('Minimalism')); ?></option>
                                                <option value="modern"><?php echo e(__('Modern')); ?></option>
                                                <option value="origami"><?php echo e(__('Origami')); ?></option>
                                                <option value="pencil"><?php echo e(__('Pencil Drawing')); ?></option>
                                                <option value="pixel"><?php echo e(__('Pixel')); ?></option>
                                                <option value="pointillism"><?php echo e(__('Pointillism')); ?></option>
                                                <option value="pop"><?php echo e(__('Pop')); ?></option>
                                                <option value="realistic"><?php echo e(__('Realistic')); ?></option>
                                                <option value="renaissance"><?php echo e(__('Renaissance')); ?></option>
                                                <option value="retro"><?php echo e(__('Retro')); ?></option>
                                                <option value="steampunk"><?php echo e(__('Steampunk')); ?></option>
                                                <option value="sticker"><?php echo e(__('Sticker')); ?></option>
                                                <option value="ukiyo"><?php echo e(__('Ukiyo')); ?></option>
                                                <option value="vaporwave"><?php echo e(__('Vaporwave')); ?></option>
                                                <option value="vector"><?php echo e(__('Vector')); ?></option>
                                                <option value="watercolor"><?php echo e(__('Watercolor')); ?></option>
                                            </select>
                                        </div>
                                        <div class="grow">
                                            <label for="image_lighting" class="form-label text-heading"><?php echo e(__('Lightning Style')); ?></label>
                                            <select id="image_lighting" name="image_lighting" class="form-control form-select bg-white placeholder:text-black">
                                                <option value="" selected="selected"><?php echo e(__('None')); ?></option>
                                                <option value="ambient"><?php echo e(__('Ambient')); ?></option>
                                                <option value="backlight"><?php echo e(__('Backlight')); ?></option>
                                                <option value="blue_hour"><?php echo e(__('Blue Hour')); ?></option>
                                                <option value="cinematic"><?php echo e(__('Cinematic')); ?></option>
                                                <option value="cold"><?php echo e(__('Cold')); ?></option>
                                                <option value="dramatic"><?php echo e(__('Dramatic')); ?></option>
                                                <option value="foggy"><?php echo e(__('Foggy')); ?></option>
                                                <option value="golden_hour"><?php echo e(__('Golden Hour')); ?></option>
                                                <option value="hard"><?php echo e(__('Hard')); ?></option>
                                                <option value="natural"><?php echo e(__('Natural')); ?></option>
                                                <option value="neon"><?php echo e(__('Neon')); ?></option>
                                                <option value="studio"><?php echo e(__('Studio')); ?></option>
                                                <option value="warm"><?php echo e(__('Warm')); ?></option>
                                            </select>
                                        </div>
                                        <div class="grow">
                                            <label for="image_mood" class="form-label text-heading"><?php echo e(__('Mood')); ?></label>
                                            <select id="image_mood" name="image_mood" class="form-control form-select bg-white placeholder:text-black">
                                                <option value="" selected="selected"><?php echo e(__('None')); ?></option>
                                                <option value="aggressive"><?php echo e(__('Aggressive')); ?></option>
                                                <option value="angry"><?php echo e(__('Angry')); ?></option>
                                                <option value="boring"><?php echo e(__('Boring')); ?></option>
                                                <option value="bright"><?php echo e(__('Bright')); ?></option>
                                                <option value="calm"><?php echo e(__('Calm')); ?></option>
                                                <option value="cheerful"><?php echo e(__('Cheerful')); ?></option>
                                                <option value="chilling"><?php echo e(__('Chilling')); ?></option>
                                                <option value="colorful"><?php echo e(__('Colorful')); ?></option>
                                                <option value="dark"><?php echo e(__('Dark')); ?></option>
                                                <option value="neutral"><?php echo e(__('Neutral')); ?></option>
                                            </select>
                                        </div>
                                        <div class="grow">
                                            <label for="image_number_of_images" class="form-label text-heading"><?php echo e(__('Number of Images')); ?></label>
                                            <select name="image_number_of_images" id="image_number_of_images" class="form-control form-select bg-white placeholder:text-black">
                                                <option value="1" selected="selected">1</option>
                                                <option value="2">2</option>
                                                <option value="3">3</option>
                                                <option value="4">4</option>
                                                <option value="5">5</option>
                                            </select>
                                        </div>

                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <div id="generator_sidebar_table">
        <?php echo $__env->make('panel.user.openai.generator_components.generator_sidebar_table', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </div>
<?php endif; ?>
<!-- End image generator -->
<?php /**PATH /Users/furkan/Work/projects/openai/openai-app/resources/views/panel/user/openai/generator_components/generator_image.blade.php ENDPATH**/ ?>