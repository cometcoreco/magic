<option value="ar-AE" <?php echo e($setting->openai_default_language == 'ar-AE' ? 'selected' : null); ?>><?php echo e(__('Arabic')); ?></option>
<option value="cmn-CN" <?php echo e($setting->openai_default_language == 'cmn-CN' ? 'selected' : null); ?>><?php echo e(__('Chinese (Mandarin)')); ?></option>
<option value="hr-HR" <?php echo e($setting->openai_default_language == 'hr-HR' ? 'selected' : null); ?>><?php echo e(__('Croatian (Croatia)')); ?></option>
<option value="cs-CZ" <?php echo e($setting->openai_default_language == 'cs-CZ' ? 'selected' : null); ?>><?php echo e(__('Czech (Czech Republic)')); ?></option>
<option value="da-DK" <?php echo e($setting->openai_default_language == 'da-DK' ? 'selected' : null); ?>><?php echo e(__('Danish (Denmark)')); ?></option>
<option value="nl-NL" <?php echo e($setting->openai_default_language == 'nl-NL' ? 'selected' : null); ?>><?php echo e(__('Dutch (Netherlands)')); ?></option>
<option value="en-US" <?php echo e($setting->openai_default_language == 'en-US' ? 'selected' : null); ?>><?php echo e(__('English (USA)')); ?></option>
<option value="et-EE" <?php echo e($setting->openai_default_language == 'et-EE' ? 'selected' : null); ?>><?php echo e(__('Estonian (Estonia)')); ?></option>
<option value="fi-FI" <?php echo e($setting->openai_default_language == 'fi-FI' ? 'selected' : null); ?>><?php echo e(__('Finnish (Finland)')); ?></option>
<option value="fr-FR" <?php echo e($setting->openai_default_language == 'fr-FR' ? 'selected' : null); ?>><?php echo e(__('French (France)')); ?></option>
<option value="de-DE" <?php echo e($setting->openai_default_language == 'de-DE' ? 'selected' : null); ?>><?php echo e(__('German (Germany)')); ?></option>
<option value="el-GR" <?php echo e($setting->openai_default_language == 'el-GR' ? 'selected' : null); ?>><?php echo e(__('Greek (Greece)')); ?></option>
<option value="he-IL" <?php echo e($setting->openai_default_language == 'he-IL' ? 'selected' : null); ?>><?php echo e(__('Hebrew (Israel)')); ?></option>
<option value="hi-IN" <?php echo e($setting->openai_default_language == 'hi-IN' ? 'selected' : null); ?>><?php echo e(__('Hindi (India)')); ?></option>
<option value="hu-HU" <?php echo e($setting->openai_default_language == 'hu-HU' ? 'selected' : null); ?>><?php echo e(__('Hungarian (Hungary)')); ?></option>
<option value="is-IS" <?php echo e($setting->openai_default_language == 'is-IS' ? 'selected' : null); ?>><?php echo e(__('Icelandic (Iceland)')); ?></option>
<option value="id-ID" <?php echo e($setting->openai_default_language == 'id-ID' ? 'selected' : null); ?>><?php echo e(__('Indonesian (Indonesia)')); ?></option>
<option value="it-IT" <?php echo e($setting->openai_default_language == 'it-IT' ? 'selected' : null); ?>><?php echo e(__('Italian (Italy)')); ?></option>
<option value="ja-JP" <?php echo e($setting->openai_default_language == 'ja-JP' ? 'selected' : null); ?>><?php echo e(__('Japanese (Japan)')); ?></option>
<option value="ko-KR" <?php echo e($setting->openai_default_language == 'ko-KR' ? 'selected' : null); ?>><?php echo e(__('Korean (South Korea)')); ?></option>
<option value="ms-MY" <?php echo e($setting->openai_default_language == 'ms-MY' ? 'selected' : null); ?>><?php echo e(__('Malay (Malaysia)')); ?></option>
<option value="nb-NO" <?php echo e($setting->openai_default_language == 'nb-NO' ? 'selected' : null); ?>><?php echo e(__('Norwegian (Norway)')); ?></option>
<option value="pl-PL" <?php echo e($setting->openai_default_language == 'pl-PL' ? 'selected' : null); ?>><?php echo e(__('Polish (Poland)')); ?></option>
<option value="pt-BR" <?php echo e($setting->openai_default_language == 'pt-BR' ? 'selected' : null); ?>><?php echo e(__('Portuguese (Brazil)')); ?></option>
<option value="pt-PT" <?php echo e($setting->openai_default_language == 'pt-PT' ? 'selected' : null); ?>><?php echo e(__('Portuguese (Portugal)')); ?></option>
<option value="ro-RO" <?php echo e($setting->openai_default_language == 'ro-RO' ? 'selected' : null); ?>><?php echo e(__('Romanian (Romania)')); ?></option>
<option value="ru-RU" <?php echo e($setting->openai_default_language == 'ru-RU' ? 'selected' : null); ?>><?php echo e(__('Russian (Russia)')); ?></option>
<option value="sl-SI" <?php echo e($setting->openai_default_language == 'sl-SI' ? 'selected' : null); ?>><?php echo e(__('Slovenian (Slovenia)')); ?></option>
<option value="es-ES" <?php echo e($setting->openai_default_language == 'es-ES' ? 'selected' : null); ?>><?php echo e(__('Spanish (Spain)')); ?></option>
<option value="sw-KE" <?php echo e($setting->openai_default_language == 'sw-KE' ? 'selected' : null); ?>><?php echo e(__('Swahili (Kenya)')); ?></option>
<option value="sv-SE" <?php echo e($setting->openai_default_language == 'sv-SE' ? 'selected' : null); ?>><?php echo e(__('Swedish (Sweden)')); ?></option>
<option value="tr-TR" <?php echo e($setting->openai_default_language == 'tr-TR' ? 'selected' : null); ?>><?php echo e(__('Turkish (Turkey)')); ?></option>
<option value="vi-VN" <?php echo e($setting->openai_default_language == 'vi-VN' ? 'selected' : null); ?>><?php echo e(__('Vietnamese (Vietnam)')); ?></option>
<?php /**PATH /Users/furkan/Work/projects/openai/openai-app/resources/views/panel/admin/settings/languages.blade.php ENDPATH**/ ?>