<?php $__env->startSection('title', $openai->title); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-header">
        <div class="container-xl">
            <div class="row g-2 items-center">
                <div class="col">
                    <div class="page-pretitle">
                        <?php echo e($openai->description); ?>

                    </div>
                    <h2 class="page-title mb-2">
                        <?php echo e($openai->title); ?>

                    </h2>
                </div>
            </div>
        </div>
    </div>
    <!-- Page body -->
    <div class="page-body page-generator pt-6">
        <div class="container-xl">
            <?php if($openai->type == 'image'): ?>
                <?php echo $__env->make('panel.user.openai.generator_components.generator_image', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php else: ?>
                <?php echo $__env->make('panel.user.openai.generator_components.generator_others', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script src="/assets/libs/tom-select/dist/js/tom-select.base.min.js?1674944402" defer></script>
    <script src="/assets/js/panel/openai_generator.js"></script>
    <script src="/assets/libs/fslightbox/index.js?1674944402" defer></script>

    <?php if($openai->type == 'code'): ?>
        <link rel="stylesheet" href="/assets/libs/prism/prism.css">
        <script src="/assets/libs/prism/prism.js"></script>
        <script>
            document.addEventListener('DOMContentLoaded', (event) => {
				"use strict";

                const codeLang = document.querySelector('#code_lang');
                const codePre = document.querySelector('#code-pre');
                const codeOutput = codePre?.querySelector('#code-output');

                if (!codeOutput) return;

                codePre.classList.add(`language-${codeLang && codeLang.value !== '' ? codeLang.value : 'javascript'}`);

                // saving for copy
                window.codeRaw = codeOutput.innerText;

                Prism.highlightElement(codeOutput);
            });
        </script>
    <?php endif; ?>

    <script>
        function sendOpenaiGeneratorForm(ev) {
			"use strict";

			ev?.preventDefault();
			ev?.stopPropagation();
            document.getElementById("openai_generator_button").disabled = true;
            document.getElementById("openai_generator_button").innerHTML = "Please Wait";
			document.querySelector('#app-loading-indicator')?.classList?.remove('opacity-0');

            var formData = new FormData();
            formData.append('post_type', '<?php echo e($openai->slug); ?>');
            formData.append('openai_id', <?php echo e($openai->id); ?>);
            formData.append('custom_template', <?php echo e($openai->custom_template); ?>);
            <?php if($openai->type == 'text'): ?>
            formData.append('maximum_length', $("#maximum_length").val());
            formData.append('number_of_results', $("#number_of_results").val());
            formData.append('creativity', $("#creativity").val());
            formData.append('tone_of_voice', $("#tone_of_voice").val());
            formData.append('language', $("#language").val());
            <?php endif; ?>
            <?php if($openai->type == 'audio'): ?>
            formData.append('file', $('#file').prop('files')[0]);
            <?php endif; ?>

            <?php if($openai->type == 'image'): ?>
            formData.append('image_style', $("#image_style").val());
            formData.append('image_lighting', $("#image_lighting").val());
            formData.append('image_mood', $("#image_mood").val());
            formData.append('image_number_of_images', $("#image_number_of_images").val());
            <?php endif; ?>

            <?php $__currentLoopData = json_decode($openai->questions); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            formData.append('<?php echo e($question->name); ?>', $("<?php echo e('#'.$question->name); ?>").val());
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            $.ajax({
                type: "post",
                url: "/dashboard/user/openai/generate",
                data: formData,
                contentType: false,
                processData: false,
                success: function (data) {
                    toastr.success('Generated Successfully!');
                    setTimeout(function () {
                        <?php if($openai->type == 'image'): ?>
                        $("#generator_sidebar_table").html(data.html2);
                        <?php elseif($openai->type == 'audio'): ?>
                        $("#generator_sidebar_table").html(data.html2);
                        <?php else: ?>
                        if ( $("#code-output").length ) {
                            $("#workbook_textarea").html(data.html2);
                            window.codeRaw = $("#code-output").text();
                            $("#code-output").addClass(`language-${$('#code_lang').val() || 'javascript'}`);
                            Prism.highlightElement($("#code-output")[0]);
                        } else {
                            tinymce.activeEditor.destroy();
                            $("#generator_sidebar_table").html(data.html2);
                            getResult();
                        }
                        <?php endif; ?>

                        document.getElementById("openai_generator_button").disabled = false;
                        document.getElementById("openai_generator_button").innerHTML = "Regenerate";
						document.querySelector('#app-loading-indicator')?.classList?.add('opacity-0');
						document.querySelector('#workbook_regenerate')?.classList?.remove('hidden');
                    }, 750);
                },
                error: function (data) {
                    if ( data.responseJSON.errors ) {
						$.each(data.responseJSON.errors, function(index, value) {
							toastr.error(value);
						});
					} else if ( data.responseJSON.message ) {
						toastr.error(data.responseJSON.message);
					}
                    document.getElementById("openai_generator_button").disabled = false;
                    document.getElementById("openai_generator_button").innerHTML = "Genarate";
					document.querySelector('#app-loading-indicator')?.classList?.add('opacity-0');
					document.querySelector('#workbook_regenerate')?.classList?.add('hidden');
                }
            });
            return false;
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('panel.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/furkan/Work/projects/openai/openai-app/resources/views/panel/user/openai/generator.blade.php ENDPATH**/ ?>