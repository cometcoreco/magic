<?php $__env->startSection('title', isset($subscription) ? 'Edit' : 'Create'.' Subscription'); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-header">
        <div class="container-xl">
            <div class="row g-2 items-center">
                <div class="col">
					<a href="<?php echo e(LaravelLocalization::localizeUrl( route('dashboard.index') )); ?>" class="page-pretitle flex items-center">
						<svg class="!me-2 rtl:-scale-x-100" width="8" height="10" viewBox="0 0 6 10" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
							<path d="M4.45536 9.45539C4.52679 9.45539 4.60714 9.41968 4.66071 9.36611L5.10714 8.91968C5.16071 8.86611 5.19643 8.78575 5.19643 8.71432C5.19643 8.64289 5.16071 8.56254 5.10714 8.50896L1.59821 5.00004L5.10714 1.49111C5.16071 1.43753 5.19643 1.35718 5.19643 1.28575C5.19643 1.20539 5.16071 1.13396 5.10714 1.08039L4.66071 0.633963C4.60714 0.580392 4.52679 0.544678 4.45536 0.544678C4.38393 0.544678 4.30357 0.580392 4.25 0.633963L0.0892856 4.79468C0.0357141 4.84825 0 4.92861 0 5.00004C0 5.07146 0.0357141 5.15182 0.0892856 5.20539L4.25 9.36611C4.30357 9.41968 4.38393 9.45539 4.45536 9.45539Z"/>
						</svg>
						<?php echo e(__('Back to dashboard')); ?>

					</a>
                    <h2 class="page-title mb-2">
                       <?php echo e(isset($subscription) ? __('Edit') : __('Create')); ?> <?php echo e(__('Subscription')); ?>

                    </h2>
                </div>
            </div>
        </div>
    </div>
    <!-- Page body -->
    <div class="page-body pt-6">
        <div class="container-xl">
			<div class="row">
				<div class="col-md-5 mx-auto">
					<form id="item_edit_form" onsubmit="return subscriptionSave(<?php echo e($subscription->id ?? null); ?>);" action="">
						<div class="row">
							<div class="col-md-12 col-xl-12">

								<div class="row">
									<div class="col-md-12">
										<div class="mb-3">
											<label class="form-label"><?php echo e(__('Plan Name')); ?></label>
											<input type="text" class="form-control" id="name" name="name" value="<?php echo e(isset($subscription) ? $subscription->name : null); ?>" required>
										</div>
									</div>
								</div>

								<div class="row">
									<div class="col-md-6">
										<div class="mb-3">
											<label class="form-label"><?php echo e(__('Price')); ?></label>
											<input type="number" class="form-control" id="price" step="0.01" name="price" value="<?php echo e(isset($subscription) ? $subscription->price : null); ?>" required>
										</div>
									</div>
								</div>

								<div class="row">
									<div class="col-md-6">
										<div class="mb-3">
											<div class="form-label"><?php echo e(__('Type')); ?></div>
											<select class="form-select" id="frequency" name="frequency" required>
												<option value="<?php echo e(isset($subscription) ? $subscription->frequency : null); ?>"><?php echo e(isset($subscription) ? $subscription->frequency : 'Select'); ?></option>
												<option value="monthly">Monthly</option>
												<option value="yearly">Yearly</option>
											</select>
										</div>
									</div>
									<div class="col-md-6">
										<div class="mb-3">
											<div class="form-label"><?php echo e(__('Featured Plan')); ?></div>
											<select class="form-select" id="is_featured" name="is_featured" required>
												<?php if(isset($subscription)): ?>
												<option value="<?php echo e($subscription->is_featured); ?>"><?php echo e($subscription->is_featured == 1 ? 'Yes' : 'No'); ?></option>
												<?php endif; ?>
												<option value="1"><?php echo e(__('Yes')); ?></option>
												<option value="0"><?php echo e(__('No')); ?></option>
											</select>
										</div>
									</div>
								</div>

								<div class="row">
									<div class="col-md-12">
										<div class="mb-3">
											<label class="form-label"><?php echo e(__('Stripe Price Id')); ?></label>
											<input type="text" name="stripe_product_id" id="stripe_product_id" class="form-control"  value="<?php echo e(isset($subscription) ? $subscription->stripe_product_id : null); ?>"/>
										</div>
									</div>
									<div class="col-md-6">
										<div class="mb-3">
											<label class="form-label"><?php echo e(__('Total Words')); ?></label>
											<input type="number" name="total_words" id="total_words" class="form-control"  value="<?php echo e(isset($subscription) ? $subscription->total_words : null); ?>"/>
										</div>
									</div>
									<div class="col-md-6">
										<div class="mb-3">
											<label class="form-label"><?php echo e(__('Total Images')); ?></label>
											<input type="number" name="total_images" id="total_images" class="form-control"  value="<?php echo e(isset($subscription) ? $subscription->total_images : null); ?>"/>
										</div>
									</div>
								</div>

								<div class="row">
									<div class="col-md-6">
										<div class="mb-3">
											<div class="form-label"><?php echo e(__('AI Name')); ?></div>
											<select class="form-select" id="ai_name" name="ai_name" required>
												<?php if(isset($subscription)): ?>
													<option value="text-davinci-003"<?php echo e($subscription->ai_name == 'text-davinci-003' ? 'selected' : null); ?>>Davinci</option>
													<option value="gpt-3.5-turbo"<?php echo e($subscription->ai_name == 'gpt-3.5-turbo' ? 'selected' : null); ?>>ChatGPT 3.5</option>
													<option value="gpt-4"<?php echo e($subscription->ai_name == 'gpt-4' ? 'selected' : null); ?>>ChatGPT 4</option>
                                                <?php else: ?>
                                                    <option value="text-davinci-003">Davinci</option>
                                                    <option value="gpt-3.5-turbo">ChatGPT 3.5</option>
                                                    <option value="gpt-4">ChatGPT 4</option>
                                                <?php endif; ?>
											</select>
										</div>
                                        <div class="alert alert-info">
                                            Please note GPT-4 is not working with every api_key. You have to have an api key which can work with GPT-4.
                                            <br>Also please note that Chat models works with ChatGPT and GPT-4 models. So if you choose below it will automatically use ChatGPT.
                                        </div>
									</div>
									<div class="col-md-6">
										<div class="mb-3">
											<label class="form-label"><?php echo e(__('Max Tokens')); ?></label>
											<input type="number" name="max_tokens" id="max_tokens" class="form-control"  value="<?php echo e(isset($subscription) ? $subscription->max_tokens : null); ?>"/>
										</div>
									</div>
									<div class="col-md-6">
										<div class="mb-3">
											<div class="form-label"><?php echo e(__('Can Create AI Images')); ?></div>
											<select class="form-select" id="can_create_ai_images" name="can_create_ai_images" required>
												<?php if(isset($subscription)): ?>
													<option value="<?php echo e($subscription->can_create_ai_images); ?>"><?php echo e($subscription->can_create_ai_images == 1 ? 'Yes' : 'No'); ?></option>
												<?php endif; ?>
												<option value="1"><?php echo e(__('Yes')); ?></option>
												<option value="0"><?php echo e(__('No')); ?></option>
											</select>
										</div>
									</div>

									<div class="col-md-6">
										<div class="mb-3">
											<div class="form-label"><?php echo e(__('Template Access')); ?></div>
											<select class="form-select" id="plan_type" name="plan_type" required>
												<?php if(isset($subscription)): ?>
													<option value="<?php echo e($subscription->plan_type); ?>"><?php echo e($subscription->plan_type); ?></option>
												<?php endif; ?>
												<option value="All"><?php echo e(__('All')); ?></option>
												<option value="Premium"><?php echo e(__('Premium')); ?></option>
												<option value="Regular"><?php echo e(__('Regular')); ?></option>
											</select>
										</div>
									</div>

									<div class="col-md-12">
										<div class="mb-3">
											<div class="form-label"><?php echo e(__('Features (Comma Seperated)')); ?></div>
											<textarea class="form-control" name="features" id="features" cols="30" rows="10" required><?php echo e(isset($subscription) ? $subscription->features : null); ?></textarea>
										</div>
									</div>
								</div>



								<button form="item_edit_form" id="item_edit_button" class="btn btn-primary w-100">
									<?php echo e(__('Save')); ?>

								</button>
							</div>
						</div>
					</form>
				</div>
			</div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script src="/assets/js/panel/finance.js"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('panel.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/furkan/Work/projects/openai/openai-app/resources/views/panel/admin/finance/plans/SubscriptionNewOrEdit.blade.php ENDPATH**/ ?>